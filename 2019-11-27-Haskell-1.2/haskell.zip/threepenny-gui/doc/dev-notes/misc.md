URL Fragment identifiers
========================

https://en.wikipedia.org/wiki/Fragment_identifier

"Clients are not supposed to send URI-fragments to servers when they retrieve a document, and without help from a local application (see below) fragments do not participate in HTTP redirections.[1]"

In particular, this means that the web server should never see the fragment identifier.
